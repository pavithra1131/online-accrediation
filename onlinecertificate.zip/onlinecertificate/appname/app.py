from flask import *

from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
engine=create_engine('postgresql://postgres:kgisl@localhost/onlineacc')

app=Flask(__name__)


app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:kgisl@localhost/onlineacc'
app.config['SECRET_KEY'] = "random string"


db = SQLAlchemy(app)
	
@app.route("/")
def index():
	return render_template("loginonline.html")
	
@app.route("/application")
def application():
	return render_template("application.html")

@app.route("/home")
def home():
	return render_template("home.html")

@app.route("/login")
def login():
	return render_template("loginonline.html")
	
@app.route("/register")
def register():
	return render_template("register.html")
	
@app.route("/elementary")
def elementary():
	return render_template("elementary.html")
	
@app.route("/primary")
def primary():
	return render_template("primary.html")
	
@app.route("/secondary")
def secondary():
	return render_template("secondary.html")
	
@app.route("/higher_secondary")
def higher_secondary():
	return render_template("higher_secondary.html")
	
@app.route("/contact")
def contact():
	return render_template("contact.html")
	
@app.route("/dashboard")
def dashboard():
	return render_template("dashboard.html")
@app.route("/about")
def about():
	return render_template("about.html")
	
@app.route("/display")
def display():
	return render_template("display.html",application=application.query.all())
	
@app.route("/approved")
def approved():
	return render_template("approved.html",application=application.query.filter_by(status=0).all())
	
@app.route("/rejected")
def rejected():
	return render_template("rejected.html",application=application.query.filter_by(status=1).all())
	

### login validation ###

@app.route('/login_check',methods= ["GET", "POST"])
def login_check():
	POST_DISPLAY_NAME=str(request.form['display_name'])
	POST_PASSWORD=str(request.form['password'])
	display_name = request.form['display_name']
	session['display_name']=display_name
	Session = sessionmaker(bind = engine)
	s = Session()
	query = s.query(register).filter(register.display_name.in_([POST_DISPLAY_NAME]),register.password.in_([POST_PASSWORD]))
	result=query.first()
	if request.form['password']=="admin" and request.form['display_name']=="admin":
		session['loggin_in'] = True 
		return redirect(url_for('home'))
		return render_template("home.html")
	
	if result:
		session['loggin_in'] = True 
		return redirect(url_for('home'))
		return render_template("home.html")
		
	else:
		flash('wrong password')
		return redirect(url_for('login'))
		return render_template('loginonline.html')
		
		



@app.route('/status_1/<id>', methods=['POST', 'GET'])
def status_1(id):
	student_id=application.query.get(id)
	student_id.status=0
	db.session.commit()
	return redirect(url_for('approved'))

@app.route('/status_2/<id>', methods=['POST', 'GET'])
def status_2(id):
	student_id=application.query.get(id)
	student_id.status=1
	db.session.commit()
	return redirect(url_for('rejected'))
		

															#   ### database for register"""	
	
class register(db.Model):
	id=db.Column('student_id',db.Integer,primary_key=True)
	first_name=db.Column(db.String)
	last_name=db.Column(db.String)
	display_name=db.Column(db.String)
	email_address=db.Column(db.String)
	password=db.Column(db.String)
	confirm_password=db.Column(db.String)
	
		
	def __init__(self,first_name,last_name,display_name,email_address,password,confirm_password):
		self.first_name=first_name
		self.last_name=last_name
		self.display_name=display_name
		self.email_address=email_address
		self.password=password
		self.confirm_password=confirm_password
		
	@app.route("/register_db",methods=["GET","POST"])
	def register_db():
		if request.method == 'POST':
			if not request.form['first_name'] or not request.form['last_name'] or not request.form['display_name'] or not request.form['email_address'] or not request.form['password'] or not request.form['confirm_password']:
				flash("Error")
			else:
				student=register(request.form['first_name'],request.form['last_name'],request.form['display_name'],request.form['email_address'],request.form['password'],request.form['confirm_password'])
				db.session.add(student)
				db.session.commit()
			return redirect(url_for('register'))
		return render_template("register.html")
		
														#    """ db for elementary"""
		
class elementary(db.Model):
	id=db.Column('student_id',db.Integer,primary_key=True)
	standard=db.Column(db.String)
	staff=db.Column(db.String)
	classes=db.Column(db.String)
	ground=db.Column(db.String)
	washrooms=db.Column(db.String)	
	
	def __init__(self,standard,staff,classes,ground,washrooms):
		self.standard=standard
		self.staff=staff
		self.classes=classes
		self.ground=ground
		self.washrooms=washrooms

	@app.route("/elementary_db",methods=["GET","POST"])
	def elementary_db():
		if request.method == 'POST':
			if not request.form['standard'] or not request.form['staff'] or not request.form['classes'] or not request.form['ground'] or not request.form['washrooms']:
				flash("Error")
			else:
				student=elementary(request.form['standard'],request.form['staff'],request.form['classes'],request.form['ground'],request.form['washrooms'])
				db.session.add(student)
				db.session.commit()
			return redirect(url_for('elementary'))
		return render_template("elementary.html")
	
															#   """db for primary"""
	 
class primary(db.Model):
	id=db.Column('student_id',db.Integer,primary_key=True)
	standard=db.Column(db.String)
	staff=db.Column(db.String)
	classes=db.Column(db.String)
	ground=db.Column(db.String)
	washrooms=db.Column(db.String)	
	
	def __init__(self,standard,staff,classes,ground,washrooms):
		self.standard=standard
		self.staff=staff
		self.classes=classes
		self.ground=ground
		self.washrooms=washrooms

	@app.route("/primary_db",methods=["GET","POST"])
	def primary_db():
		if request.method == 'POST':
			if not request.form['standard'] or not request.form['staff'] or not request.form['classes'] or not request.form['ground'] or not request.form['washrooms']:
				flash("Error")
			else:
				student=primary(request.form['standard'],request.form['staff'],request.form['classes'],request.form['ground'],request.form['washrooms'])
				db.session.add(student)
				db.session.commit()
			return redirect(url_for('primary'))
		return render_template("primary.html")
	
															#     """db for secondary"""
	
class secondary(db.Model):
	id=db.Column('student_id',db.Integer,primary_key=True)
	Standard=db.Column(db.String)
	Staff=db.Column(db.String)
	Classes=db.Column(db.String)
	Ground=db.Column(db.String)
	Computer=db.Column(db.String)	
	Science=db.Column(db.String)	
	wash_rooms=db.Column(db.String)	
	
	def __init__(self,Standard,Staff,Classes,Ground,Computer,Science,wash_rooms):
		self.Standard=Standard
		self.Staff=Staff
		self.Classes=Classes
		self.Ground=Ground
		self.Computer=Computer
		self.Science=Science
		self.wash_rooms=wash_rooms

	@app.route("/secondary_db",methods=["GET","POST"])
	def secondary_db():
		if request.method == 'POST':
			if not request.form['Standard'] or not request.form['Staff'] or not request.form['Classes'] or not request.form['Ground'] or not request.form['Computer'] or not request.form['Science'] or not request.form['wash_rooms']:
				flash("Error")
			else:
				student=secondary(request.form['Standard'],request.form['Staff'],request.form['Classes'],request.form['Ground'],request.form['Computer'],request.form['Science'],request.form['wash_rooms'])
				db.session.add(student)
				db.session.commit()
			return redirect(url_for('secondary'))
		return render_template("secondary.html")
	
													#	"""db for higher secondary"""
	
class higher_secondary(db.Model):
	id=db.Column('student_id',db.Integer,primary_key=True)
	Standard=db.Column(db.String)
	Staff=db.Column(db.String)
	Classes=db.Column(db.String)
	Ground=db.Column(db.String)
	Computer=db.Column(db.String)	
	physics=db.Column(db.String)	
	Science=db.Column(db.String)	
	wash_rooms=db.Column(db.String)	
	
	def __init__(self,Standard,Staff,Classes,Ground,Computer,physics,Biology,chemistry,wash_rooms):
		self.Standard=Standard
		self.Staff=Staff
		self.Classes=Classes
		self.Ground=Ground
		self.Computer=Computer
		self.physics=physics
		self.Biology=Biology
		self.chemistry=chemistry		
		self.wash_rooms=wash_rooms

	@app.route("/higher_secondary_db",methods=["GET","POST"])
	def higher_secondary_db():
		if request.method == 'POST':
			if not request.form['Standard'] or not request.form['Staff'] or not request.form['Classes'] or not request.form['Ground'] or not request.form['Computer'] or not request.form['physics'] or not request.form['Biology'] or not request.form['chemistry'] or not request.form['wash_rooms']:
				flash("Error")
			else:
				student=higher_secondary(request.form['Standard'],request.form['Staff'],request.form['Classes'],request.form['Ground'],request.form['Computer'],request.form['physics'],request.form['Biology'],request.form['chemistry'],request.form['wash_rooms'])
				db.session.add(student)
				db.session.commit()
			return redirect(url_for('higher_secondary'))
		return render_template("higher_secondary.html")
	
													#		"""db for contact"""
	
class contact(db.Model):
	id=db.Column('student_id',db.Integer,primary_key=True)
	Name=db.Column(db.String)
	Email_Address=db.Column(db.String)
	Message=db.Column(db.String)
	Subject=db.Column(db.String)
	
	def __init__(self,Name,Email_Address,Message,Subject):
		self.Name=Name
		self.Email_Address=Email_Address
		self.Message=Message
		self.Subject=Subject

	@app.route("/contact_db",methods=["GET","POST"])
	def contact_db():
		if request.method == 'POST':
			if not request.form['Name'] or not request.form['Email_Address'] or not request.form['Message'] or not request.form['Subject']:
				flash("Error")
			else:
				student=contact(request.form['Name'],request.form['Email_Address'],request.form['Message'],request.form['Subject'])
				db.session.add(student)
				db.session.commit()
			return redirect(url_for('contact'))
		return render_template("contact.html")
		
													#	"""db for application"""
				
class application(db.Model):
	id=db.Column('student_id',db.Integer,primary_key=True)
	Category=db.Column(db.String)
	Address=db.Column(db.String)
	Secretray=db.Column(db.String)
	Manager=db.Column(db.String)
	buses_vans=db.Column(db.String)	
	driving_licence=db.Column(db.String)	
	School_name=db.Column(db.String)	
	Chairman=db.Column(db.String)	
	Principal=db.Column(db.String)	
	staffs=db.Column(db.String)	
	form2_I=db.Column(db.String)	
	form2_II=db.Column(db.String)	
	form2_III=db.Column(db.String)	
	form2_IV=db.Column(db.String)	
	form2_V=db.Column(db.String)	
	form2_VI=db.Column(db.String)	
	form2_VII=db.Column(db.String)	
	form2_VIII=db.Column(db.String)	
	form2_IX=db.Column(db.String)	
	form2_X=db.Column(db.String)	
	form2_XI=db.Column(db.String)	
	Room_description=db.Column(db.String)
	status=db.Column(db.Integer)

	def __init__(self,Category,Address,Secretray,Manager,buses_vans,driving_licence,School_name,Chairman,Principal,staffs,form2_I,form2_II,form2_III,form2_IV,form2_V,form2_VI,form2_VII,form2_VIII,form2_IX,form2_X,form2_XI,Room_description,status):
		self.Category=Category
		self.Address=Address
		self.Secretray=Secretray
		self.Manager = Manager
		self.buses_vans=buses_vans 
		self.driving_licence=driving_licence
		self.School_name=School_name
		self.Chairman=Chairman
		self.Principal=Principal
		self.staffs=staffs
		self.form2_I=form2_I
		self.form2_II=form2_II
		self.form2_III=form2_III
		self.form2_IV=form2_IV
		self.form2_V=form2_V		
		self.form2_VI=form2_VI
		self.form2_VII=form2_VII
		self.form2_VIII=form2_VIII
		self.form2_IX=form2_IX
		self.form2_X=form2_X
		self.form2_XI=form2_XI
		self.Room_description=Room_description
		self.status=status

		
	@app.route("/application_db",methods=["GET","POST"])
	def application_db():
		if request.method == 'POST':
			if not request.form['Category'] or not request.form['Address'] or not request.form['Secretray'] or not request.form['Manager'] or not request.form['buses_vans'] or not request.form['driving_licence'] or not request.form['School_name'] or not request.form['Chairman'] or not request.form['Principal'] or not request.form['staffs'] or not request.form['form2_I'] or not request.form['form2_II'] or not request.form['form2_III'] or not request.form['form2_IV'] or not request.form['form2_V'] or not request.form['form2_VI'] or not request.form['form2_VII'] or not request.form['form2_VIII'] or not request.form['form2_IX'] or not request.form['form2_X'] or not request.form['form2_XI'] or not request.form['Room_description'] or not request.form['status']:
				pass
			else:
				student=application(request.form['Category'],request.form['Address'],request.form['Secretray'],request.form['Manager'],request.form['buses_vans'],request.form['driving_licence'],request.form['School_name'],request.form['Chairman'],request.form['Principal'],request.form['staffs'],request.form['form2_I'],request.form['form2_II'],request.form['form2_III'],request.form['form2_IV'],request.form['form2_V'],request.form['form2_VI'],request.form['form2_VII'],request.form['form2_VIII'],request.form['form2_IX'],request.form['form2_X'],request.form['form2_XI'],request.form['Room_description'],request.form['status'])
				db.session.add(student)
				db.session.commit()
			return redirect(url_for('application'))
		return render_template("application.html")

	
		
if __name__=='__main__':
	db.create_all()
	app.run(debug = True)

